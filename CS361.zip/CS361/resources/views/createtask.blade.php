@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Create Task') }}</div>

                    <div class="card-body">
                        <form>
                            <div class="mb-3">
                                <label for="taskTitle" class="form-label">Task Title</label>
                                <input type="text" class="form-control" id="taskTitle" placeholder="Enter task title">
                            </div>
                            <div class="mb-3">
                                <label for="assignee" class="form-label">Assignee</label>
                                <select class="form-select" id="assignee">
                                    <option selected>Choose assignee</option>
                                    <option>Mohammed Al Dehaimi</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="dueDate" class="form-label">Due Date</label>
                                <input type="date" class="form-control" id="dueDate">
                            </div>
                            <div class="mb-3">
                                <label for="project" class="form-label">Project</label>
                               <p> Environment Setup, Course project plan, and Sprint 1 plan</p>
                            </div>
                            <button type="submit" class="btn btn-primary">Create Task</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
