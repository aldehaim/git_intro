@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>{{ __('Sprint 1') }}</span>
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                ...
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <li><a class="dropdown-item" href="#">Rename Section</a></li>
                                <li><a class="dropdown-item" href="#" onclick="confirmDelete()">Delete Section</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="card-body">

                            <div class="col-md-12 mt-2">
                                <div class="card">
                                    <div class="card-body">
                                        <button class="btn btn-link fw-bold" onclick="handleAssignTaskClick()">Assign Task to Team Member and set Task Priority</button>
                                    </div>
                                </div>
                            </div>

                        <div class="row mt-3">
                            <div class="col-md-12">
                                <input type="text" class="form-control" placeholder="Write a task name">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <button class="btn btn-primary" onclick="handleAddTaskClick()">Create Task</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal" id="deleteSectionModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete Section</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this section?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" onclick="deleteSection()">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete() {
            if (confirm('Are you sure you want to delete this section? Warning: By clicking yes, you will not be able to get this section back')) {
                deleteSection();
            }
        }

        function deleteSection() {
            $('#deleteSectionModal').modal('hide');
            alert('Section deleted successfully!');
        }


        function handleAssignTaskClick() {
            window.location.href = "{{ route('assigntask') }}";
        }

        function handleSetTaskPriorityClick() {
            alert('Set Task Priority clicked');
        }
        function handleAddTaskClick() {
            alert('Add Task clicked');
        }
    </script>
@endsection
