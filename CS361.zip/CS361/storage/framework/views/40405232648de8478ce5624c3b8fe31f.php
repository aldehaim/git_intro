<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Assign Task to Team Member and Set task Priority')); ?></div>

                    <div class="card-body">
                        <form>
                            <div class="mb-3">
                                <label for="taskTitle" class="form-label">Task Title</label>
                                <input type="text" class="form-control" id="taskTitle" placeholder="Enter task title">
                            </div>
                            <div class="mb-3">
                                <label for="assignee" class="form-label">Assignee</label>
                                <select class="form-select" id="assignee">
                                    <option selected>Choose assignee</option>
                                    <option>Mohammed Al Dehaimi</option>
                                    <option>Abel David</option>
                                </select>
                                <small id="assigneeHelp" class="form-text text-muted">Or you can directly type the assignee's name</small>
                                <input type="text" class="form-control mt-2" id="customAssignee" placeholder="Type assignee's name">
                            </div>
                            <div class="mb-3">
                                <label for="dueDate" class="form-label">Due Date</label>
                                <input type="date" class="form-control" id="dueDate">
                            </div>
                            <div class="mb-3">
                                <label for="project" class="form-label">Project</label>
                                <p> Environment Setup, Course project plan, and Sprint 1 plan</p>
                            </div>
                            <div class="mb-3">
                                <label for="priority" class="form-label">Priority</label>
                                <select class="form-select" id="priority">
                                    <option selected>Choose priority</option>
                                    <option>Low</option>
                                    <option>Medium</option>
                                    <option>High</option>
                                </select>
                            </div>
                            <div class="d-flex justify-content-between">
                                <button type="button" class="btn btn-secondary" onclick="goBack()">Back</button>
                                <button type="submit" class="btn btn-primary">Done</button>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // JavaScript function to navigate back to the previous page
        function goBack() {
            window.history.back();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\PhpstormProjects\CS361\resources\views/assigntask.blade.php ENDPATH**/ ?>