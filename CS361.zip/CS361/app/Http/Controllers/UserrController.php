<?php

namespace App\Http\Controllers;

use App\Models\Userr;
use Illuminate\Http\Request;

class UserrController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('login');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        if ($request->email != '' and $request->password != '') {
            if ($user=Userr::where("email", $request->email)->where("password", $request->password)->first()) {

                return view('taskorganization')->with(['user_id' => $user->id]);
            }
            return back()->with('error', 'Invalid email or password.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Userr $userr)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Userr $userr)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Userr $userr)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Userr $userr)
    {
        //
    }
}
