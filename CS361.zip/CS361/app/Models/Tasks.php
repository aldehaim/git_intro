<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tasks extends Model
{
    use HasFactory;
    protected $fillable = [
        'title', 'description', 'priority', 'assignee_id',
    ];

    public function assignee()
    {
        return $this->belongsTo(Userr::class, 'assignee_id');
    }
}
